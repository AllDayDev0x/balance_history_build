module.exports = {
    accounts: [
        "0x48e9b211321206D4A9CC3754efdbDC9828dFcC07",
        "0x86873052C4bF77e5aE0Be301ef4E8c57E46c41EB",

    ],
    rpc: {
        wss: "wss://eth-mainnet.g.alchemy.com/v2/8KNx5j9eeU5L2LJa4-jPEFh6en98mOaG",//your provider
        https: "https://eth-mainnet.g.alchemy.com/v2/8KNx5j9eeU5L2LJa4-jPEFh6en98mOaG"

    },
    EtherScan_API_KEY: "B317BGY7FU3Y2NMM9NNF2T4BJHMI795QRF",
    port:80

};