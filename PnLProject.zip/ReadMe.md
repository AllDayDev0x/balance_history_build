1. Install the MongoDB.5.0
2. Set "C:\Program Files\MongoDB\Server\5.0\bin" to system evironment path 

    - open the CLI
    - execute follow command
        `setx path "C:\Program Files\MongoDB\Server\5.0\bin"`
3. set the config.js
4. `npm start`
